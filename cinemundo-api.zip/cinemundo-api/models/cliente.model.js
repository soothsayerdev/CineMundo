const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Cliente = sequelize.define('Cliente', {
  ID: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true
  },
  Nome_Completo: {
    type: DataTypes.STRING(150),
    allowNull: false
  },
  Data_Aniversario: DataTypes.DATE,
  Endereco_Completo: DataTypes.STRING(255),
  Celular: DataTypes.STRING(20),
  Email: {
    type: DataTypes.STRING(100),
    unique: true
  },
  CPF: {
    type: DataTypes.CHAR(11),
    unique: true
  },
  Senha: {
    type: DataTypes.STRING(100),
    allowNull: false
  },
  Paga_Meia_Entrada: {
    type: DataTypes.BOOLEAN,
    defaultValue: false
  }
}, {
  tableName: 'Cliente',
  timestamps: false
});

module.exports = Cliente;
