const express = require('express');
const app = express();
const sequelize = require('./config/database');

app.use(express.json());

// Rotas
const clienteRoutes = require('./routes/cliente.routes');
app.use('/api/clientes', clienteRoutes);

// Conectar com o banco
sequelize.authenticate()
  .then(() => console.log('Conectado ao banco SQL Server ✅'))
  .catch((err) => console.error('Erro na conexão com o banco ❌', err));

module.exports = app;
